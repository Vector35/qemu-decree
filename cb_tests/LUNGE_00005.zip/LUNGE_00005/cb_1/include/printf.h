#ifndef CGC_PRINTF
#define CGC_PRINTF
size_t printf(int fd, const char *format, ...);
#endif
