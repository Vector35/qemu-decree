#ifndef CTYPE_H_
#define CTYPE_H_

int isascii(int c);
int isprint(int c);
int isalnum(int c);
int isalpha(int c);
int islower(int c);
int isupper(int c);
int isspace(int c);
int ispunct(int c);
int tolower(int c);
int toupper(int c);

#endif /* !CTYPE_H_ */
