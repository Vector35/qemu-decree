# DEFCON CTF Tribute

## Author Information

Chris Eagle

### DARPA performer Group

Naval Postgraduate School

## Description

This CGC service is a tribute to the menage service from DEFCON 15's
Capture-the-Flag competition. Menage is considered one of the hardest
services ever fielded in the human CTF circuit. It has been adapted for
CGC by removing a number of features but preserving its use of
interprocess communication.

### Feature List

This CB implements IPC amongst several binaries
